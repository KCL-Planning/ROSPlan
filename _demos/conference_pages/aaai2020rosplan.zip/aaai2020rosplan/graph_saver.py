#!/usr/bin/env python
import rospy
from std_msgs.msg import String

def callback_plan(data):
    f1 = open("plan.dot", "w")
    f1.write(data.data)
    f1.close()

def listener():
    rospy.init_node('graph_saver', anonymous=True)
    rospy.Subscriber("/rosplan_plan_dispatcher/plan_graph", String, callback_plan)
    rospy.spin()

if __name__ == '__main__':
    listener()
