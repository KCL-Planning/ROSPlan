killall -9 xdot;
python graph_saver.py & xdot plan.dot
killall -9 python;
