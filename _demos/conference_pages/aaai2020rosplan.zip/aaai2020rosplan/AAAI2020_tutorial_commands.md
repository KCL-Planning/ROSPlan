export TURTLEBOT3_MODEL="waffle"

# 00 ROS

(with roslaunch rosplan_stage_demo empty_stage.launch)

rosnode list
rosnode info /map_server

rosparam get /robot/name
rosparam set /robot/name "Kenny"
rosparam get /robot/name

rostopic list
rostopic info /base_scan
rostopic echo base_scan -n 2 -p

rosservice list
rosservice call /static_map "{}"

rqt --standalone rqt_graph.ros_graph.RosGraph

# 01 problem_instance

(using tutorial_01.launch)

rosnode list
rosservice list
rosservice call /rosplan_problem_interface/problem_generation_server
cat src/rosplan_demos/rosplan_demos/common/problem.pddl
rostopic echo /rosplan_problem_interface/problem_instance -n 1 -p

# 02 planning

(using tutorial_02.launch)

rqt --standalone rqt_graph.ros_graph.RosGraph
rosservice call /rosplan_problem_interface/problem_generation_server
rosservice call /rosplan_planner_interface/planning_server
rostopic echo /rosplan_planner_interface/planner_output -n 1 -p
cat tutorial_02.bash
./tutorial_02.bash

# 03 plan execution A

(using tutorial_03.launch)

rqt --standalone rqt_graph.ros_graph.RosGraph
./tutorial_02.bash
rosservice call /rosplan_parsing_interface/parse_plan
rostopic echo /rosplan_planner_interface/planner_output -n 1 -p
rostopic echo /rosplan_parsing_interface/complete_plan -n 1
rosmsg show rosplan_dispatch_msgs/CompletePlan -r
rosmsg show rosplan_dispatch_msgs/CompletePlan

# 04 plan execution B

(using tutorial_04.launch)

rqt --standalone rqt_graph.ros_graph.RosGraph
rostopic echo /rosplan_knowledge_base/pddl_action_parameters -n 3
cat tutorial_04.bash
./tutorial_04.bash

# 05 plan execution C

(using tutorial_05.launch)

rosmsg show rosplan_dispatch_msgs/CompletePlan
rosmsg show rosplan_dispatch_msgs/EsterelPlan -r
rosmsg show rosplan_dispatch_msgs/EsterelPlan
./show_plans.bash & ./tutorial_04.bash

# 06 knowledge base

(using tutorial_01.launch)

rosservice list | grep domain
rosservice call /rosplan_knowledge_base/domain/types
rosservice call /rosplan_knowledge_base/domain/predicates
rosservice call /rosplan_knowledge_base/domain/operator_details "name: 'goto_waypoint'"

rosservice list | grep state
cat src/rosplan_demos/rosplan_demos/common/problem.pddl
rosservice call /rosplan_knowledge_base/state/instances "type_name: 'robot'"
rosservice call /rosplan_knowledge_base/state/instances "type_name: 'waypoint'"
rosservice call /rosplan_knowledge_base/state/propositions "predicate_name: 'robot_at'"
rosservice call /rosplan_knowledge_base/state/propositions "predicate_name: ''"
rosservice call /rosplan_knowledge_base/state/goals "predicate_name: ''"

# 07 updating the state

(using tutorial_07.launch)

rossrv show rosplan_knowledge_msgs/KnowledgeUpdateServiceArray -r
rosmsg show rosplan_knowledge_msgs/KnowledgeItem -r

rostopic pub /localised_mock std_msgs/Bool "data: true" -1
rosservice call /rosplan_knowledge_base/state/propositions "predicate_name: 'localised'"
rostopic pub /localised_mock std_msgs/Bool "data: false" -1
rosservice call /rosplan_knowledge_base/state/propositions "predicate_name: 'localised'"

rqt --standalone rqt_publisher.publisher.Publisher & rostopic echo /mobile_base/sensors/core

(Try setting charger to 1 or 0. Witness the message published and the effect on the knowledge base.)

# 08 fully connected example

(using tutorial_08.launch)

(move robot and observe sensor interface)
./show_plans.bash & ./tutorial_04.bash
rqt --standalone rqt_graph.ros_graph.RosGraph

# STPlanning

(using rosplan_interface_strategic strategic_tactical.launch)

rqt --standalone rqt_graph.ros_graph.RosGraph
./strategic_show_plans.bash & ./strategic_plan.bash
