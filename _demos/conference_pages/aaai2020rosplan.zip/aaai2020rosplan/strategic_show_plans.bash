killall -9 xdot;
python strategic_graph_saver.py & xdot strategic_plan.dot & xdot tactical_plan.dot;
killall -9 python;
